//
//  SearchViewController.swift
//  MyPinterest_LittleTiger
//
//  Created by Qianyu on 16/8/8.
//  Modified by John Zhou 
//  Copyright © 2016年 Carnegie Mellon University. All rights reserved.
//

import UIKit
//import FlickrKit

class SearchViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate{
    
    var photoURLs: [NSURL]!
    var _dataArr = NSMutableArray()

    @IBOutlet weak var searchText: UITextField!
    @IBOutlet weak var SearchView: UICollectionView!
    @IBAction func onClick(sender: AnyObject) {
        
        SearchView.reloadData()

        
    }
    //private var photoCollectionView
    
    //@IBOutlet weak var searchOutput: UICollectionView!
    /*
    @IBAction func onClick(sender: AnyObject) {
        var _flickrKitModel:FlickrKit = FlickrKit.sharedFlickrKit()//singleton
        _flickrKitModel.initializeWithAPIKey("22a884d55650bb34ca04ddc843d8a0e3", sharedSecret: "2cc44921f60ec846")
        //self.searchOutput.
        //self.searchResultShow.        
    }
    */
    
    //override func loadView() {
    //}
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.photoURLs = []
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        var _flickrKitModel:FlickrKit = FlickrKit.sharedFlickrKit()//singleton
        _flickrKitModel.initializeWithAPIKey("22a884d55650bb34ca04ddc843d8a0e3", sharedSecret: "2cc44921f60ec846")
        
        let i = 1
        let _cell:collectionCell = collectionView.dequeueReusableCellWithReuseIdentifier("collectionCell", forIndexPath: indexPath) as! collectionCell
        let _frame1 = CGRect(x:0, y:0, width:100,height:40)
        let nil_label = UILabel(frame: _frame1)
        nil_label.tag = 1;
        nil_label.text = searchText?.text
        
        _flickrKitModel.call("flickr.photos.search", args: ["api_key":"22a884d55650bb34ca04ddc843d8a0e3", "text":(searchText?.text)!, "per_page": "15"],  maxCacheAge: FKDUMaxAgeNeverCache, completion: { (response, error) -> Void in
                let topPhotos = response["photos"] as! [NSObject: AnyObject]
                let photoArray = topPhotos["photo"] as! [[NSObject: AnyObject]]
                for photoDictionary in photoArray {
                    let photoURL = _flickrKitModel.photoURLForSize(FKPhotoSizeSmall240, fromPhotoDictionary: photoDictionary)
                    if photoURL != nil {
                        self.photoURLs.append(photoURL)
                    }
                }
            })
        for url in self.photoURLs {
            let urlRequest = NSURLRequest(URL: url)
            NSURLConnection.sendAsynchronousRequest(urlRequest, queue: NSOperationQueue.mainQueue(), completionHandler: { (response, data, error) -> Void in
                
                let _image = UIImage(data: data!)
                let _imageView = UIImageView(image:_image)
                let _frame2 = CGRect(x:0, y:50, width:100,height:40)
                _cell.imageView?.image = _image
                _cell.contentView.addSubview(_imageView)
            })
        }

        nil_label.backgroundColor = UIColor.brownColor()
        _cell.contentView.addSubview(nil_label)
        return _cell
    }
    
    /*
    
     func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
     
     let cell = _collectView.dequeueReusableCellWithReuseIdentifier("cell", forIndexPath: indexPath) as! MyPhotosCollectionViewCell
     
     let dic = _dataArr.objectAtIndex(indexPath.row)
     cell._nameLbl.text = dic.objectForKey("owner") as? String
     let photoURL = FlickrKit.sharedFlickrKit().photoURLForSize(FKPhotoSizeSmall240, fromPhotoDictionary: dic as! [NSObject : AnyObject])
     if let photoURL = photoURL {
     
     cell._logoImgV.hnk_setImageFromURL(photoURL)       // 异步载入图片。本地会缓存图片
     //            if let data = NSData(contentsOfURL: photoURL){
     //
     //                cell._logoImgV.image = UIImage(data:data)
     //            }
     
     }
     cell._titleLbl.text = dic.objectForKey("title") as? String
     return cell
     */
 
 
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int{
        
        //collectionView.collectionViewLayout(invalidateLayout);
        //[myCollectionView.collectionViewLayout invalidateLayout];
        return 3
        
    }
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath){
        
    }
    func collectionView(collectionView: UICollectionView, didDeselectItemAtIndexPath indexPath: NSIndexPath){
        // Definition conflicts with previous value
    }

}
