//
//  photoCollectionView.swift
//  MyPinterest_LittleTiger
//
//  Created by M'K on 8/25/16.
//  Copyright © 2016 Carnegie Mellon University. All rights reserved.
//
import UIKit
import Foundation

class photoCollectionView:UICollectionView, UICollectionViewDataSource, UICollectionViewDelegate{
    //UIViewController, UICollectionViewDataSource, UICollectionViewDelegate
    var cv: UICollectionView!
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        //返回记录数
        return 5;
    }
    
    /*
    override func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1    //1
    }
     */
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell
    {
        //返回Cell内容，这里我们使用刚刚建立的defaultCell作为显示内容
        var cell:collectionCell  = cv.dequeueReusableCellWithReuseIdentifier("SearchCell", forIndexPath: indexPath) as! collectionCell
        //cell.label.text = "\(indexPath.section):\(indexPath.row)"
        cell.tintColor = UIColor.yellowColor()
        cell.label.text = "aaa"
        cell.label.highlightedTextColor = UIColor.yellowColor()
        //backgroundColor = UIColor.yellowColor()
        return cell;
        
        
        

        
        
    }
    
    func viewDidLoad() {
        //cv!.collectionvew
        //dataSource = self
        //cv!.delegate = self
        cv!.registerClass(collectionCell.self, forCellWithReuseIdentifier: "SearchCell")
        self.cv!.delegate = self
        self.cv!.dataSource = self
    }
    

}

   