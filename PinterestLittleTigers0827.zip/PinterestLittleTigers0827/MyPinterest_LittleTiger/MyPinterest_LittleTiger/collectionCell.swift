//
//  collectionCell.swift
//  MyPinterest_LittleTiger
//
//  Created by M'K on 8/25/16.
//  Copyright © 2016 Carnegie Mellon University. All rights reserved.
//

import Foundation
import UIKit



class collectionCell : UICollectionViewCell{
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var label: UILabel!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        //return self
    }
    
    convenience   required   init(coder : NSCoder){
        self.init(frame:CGRect(x: 0, y: 0, width: 50, height: 50))
    }
    //在 init 前加上 convenience 关键字的初始化方法。这类方法只作为补充和提供使用上的方便。所有的 convenience 初始化方法都必须调用同一个类中的 designated 初始化完成设置，另外 convenience 的初始化方法是不能被子类重写或者是从子类中以 super 的方式被调用的。
    
}
