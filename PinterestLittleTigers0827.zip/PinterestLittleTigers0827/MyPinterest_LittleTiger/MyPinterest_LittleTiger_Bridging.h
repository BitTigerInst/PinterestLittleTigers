//
//  MyPinterest_LittleTiger.h
//  MyPinterest_LittleTiger
//
//  Created by M'K on 8/27/16.
//  Copyright © 2016 Carnegie Mellon University. All rights reserved.
//

#ifndef MyPinterest_LittleTiger_h
#define MyPinterest_LittleTiger_h


#endif /* MyPinterest_LittleTiger_h */

#import "FlickrKit.h"
